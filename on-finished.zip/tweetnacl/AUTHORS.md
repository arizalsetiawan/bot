List of TweetNaCl.js authors
============================

    Alphabetical order by first name.
    Format: Name (GitHub username or URL)

* AndSDev (@AndSDev)
* Devi Mandiri (@devi)
* Dmitry Chestnykh (@dchest)

List of authors of third-party public domain code from which TweetNaCl.js code was derived
==========================================================================================

[TweetNaCl](http://tweetnacl.cr.yp.to/)
--------------------------------------

* Bernard van Gastel
* Daniel J. Bernstein <http://cr.yp.to/djb.html>
* Peter Schwabe <http://www.cryptojedi.org/users/peter/>
* Sjaak Smetsers <http://www.cs.ru.nl/~sjakie/>
* Tanja Lange <http://hyperelliptic.org/tanja>
* Wesley Janssen


[Poly1305-donna](https://github.com/floodyberry/poly1305-donna)
--------------------------------------------------------------

* Andrew Moon (@floodyberry)
