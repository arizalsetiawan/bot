# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [2.0.3](https://github.com/medikoo/es6-weak-map/compare/v2.0.2...v2.0.3) (2019-06-07)
