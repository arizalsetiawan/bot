const BaseKeyType = {
  OURS: 1,
  THEIRS: 2,
};

module.exports = BaseKeyType;
