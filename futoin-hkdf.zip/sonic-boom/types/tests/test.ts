import { SonicBoom } from '../../'

const sonic = new SonicBoom({ fd: process.stdout.fd })
sonic.write('hello sonic\n')
