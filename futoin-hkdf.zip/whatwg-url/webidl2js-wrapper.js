"use strict";

const URL = require("./lib/URL");
const URLSearchParams = require("./lib/URLSearchParams");

exports.URL = URL;
exports.URLSearchParams = URLSearchParams;
