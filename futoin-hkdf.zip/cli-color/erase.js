'use strict';

module.exports = {
	screen: '\x1b[2J',
	screenLeft: '\x1b[1J',
	screenRight: '\x1b[J',
	line: '\x1b[2K',
	lineLeft: '\x1b[1K',
	lineRight: '\x1b[K'
};
