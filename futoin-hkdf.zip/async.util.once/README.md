# async.util.once

![Last version](https://img.shields.io/github/tag/async-js/async.util.once.svg?style=flat-square)
[![Dependency status](http://img.shields.io/david/async-js/async.util.once.svg?style=flat-square)](https://david-dm.org/async-js/async.util.once)
[![Dev Dependencies Status](http://img.shields.io/david/dev/async-js/async.util.once.svg?style=flat-square)](https://david-dm.org/async-js/async.util.once#info=devDependencies)
[![NPM Status](http://img.shields.io/npm/dm/async.util.once.svg?style=flat-square)](https://www.npmjs.org/package/async.util.once)
[![Donate](https://img.shields.io/badge/donate-paypal-blue.svg?style=flat-square)](https://paypal.me/kikobeats)

> async once helper method as module.

This module is used internally by [async](https://github.com/async-js/async).

## License

MIT © [async-js](https://github.com/async-js)
