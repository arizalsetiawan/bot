# os

This is a Node.js Core Module

# There's no need to install through npm

**Really, there's no need, just require/import it :)**

## API

https://nodejs.org/api/os.html
