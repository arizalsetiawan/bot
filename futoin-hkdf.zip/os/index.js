module.exports = require('os')
